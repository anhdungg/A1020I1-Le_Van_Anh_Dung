create
    definer = root@localhost procedure edit_customer(IN customer_id int, IN customer_id_loai_khach_hang int,
                                                     IN customer_ho_ten varchar(45), IN customer_ngay_sinh date,
                                                     IN customer_CMND varchar(45),
                                                     IN customer_so_dien_thoai varchar(45),
                                                     IN customer_email varchar(45), IN customer_dia_chi varchar(45))
begin
	update khach_hang
    set id_loai_khach_hang = customer_id_loai_khach_hang, ho_ten = customer_ho_ten, ngay_sinh = customer_ngay_sinh, CMND = customer_CMND,
		so_dien_thoai = customer_so_dien_thoai, email = customer_email, dia_chi = customer_dia_chi
    where id_khach_hang = customer_id;
end;

