create
    definer = root@localhost procedure new_customer(IN customer_id_loai_khach_hang int, IN customer_ho_ten varchar(45),
                                                    IN customer_ngay_sinh date, IN customer_CMND varchar(45),
                                                    IN customer_so_dien_thoai varchar(45),
                                                    IN customer_email varchar(45), IN customer_dia_chi varchar(45))
begin
	insert into khach_hang(id_loai_khach_hang, ho_ten, ngay_sinh, CMND, so_dien_thoai, email, dia_chi)
    value (customer_id_loai_khach_hang, customer_ho_ten, customer_ngay_sinh, customer_CMND, customer_so_dien_thoai,
			customer_email, customer_dia_chi);
end;

