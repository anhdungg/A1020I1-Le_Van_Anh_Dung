create
    definer = root@localhost procedure delete_customer(IN customer_id int)
begin
	delete from khach_hang where id_khach_hang = customer_id;
end;

