create
    definer = root@localhost procedure find_customer_by_id(IN customer_id int)
begin
	select * from khach_hang where id_khach_hang = customer_id;
end;

