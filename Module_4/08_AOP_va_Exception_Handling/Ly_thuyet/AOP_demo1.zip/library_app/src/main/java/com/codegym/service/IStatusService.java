package com.codegym.service;

public interface IStatusService {
    void createStatus();
}
