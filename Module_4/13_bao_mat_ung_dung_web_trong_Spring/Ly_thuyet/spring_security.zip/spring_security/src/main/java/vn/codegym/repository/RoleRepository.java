package vn.codegym.repository;

import org.springframework.data.repository.Repository;
import vn.codegym.model.Role;

public interface RoleRepository extends Repository<Role, Long> {
}
