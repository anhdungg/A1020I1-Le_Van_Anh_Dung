package vn.codegym.services.impl;

import vn.codegym.model.User;
import vn.codegym.services.UserService;

import java.util.List;

public class UserServerImpl implements UserService {
    @Override
    public List<User> findAll() {
        return null;
    }

    @Override
    public void save(User user) {

    }

    @Override
    public void update(User user) {

    }

    @Override
    public User findById(int id) {
        return null;
    }
}
